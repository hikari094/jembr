from ._impl import get_active_account, set_active_account, remove_active_account
